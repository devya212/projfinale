package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author Vishal Talwar ,Deepak sharma
 * @since September 2018
 */
@Entity
@Table(name = "pfinnnewuser")
@SequenceGenerator(name="pfinnnewuserSequenceGenerator" , sequenceName="pfinnnewuserSequenceGenerator" ,initialValue=1)

public class PFinnNewUser {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator="pfinnnewuserSequenceGenerator")
	private long userID;

	@NotEmpty(message = "USER NAME cannot be Empty")
	private String username;

	@NotEmpty(message = "FIRST NAME cannot be Empty")
	private String firstName;

	@NotEmpty(message = "LAST NAME cannot be Empty")
	private String lastName;

	private String interestArea;

	@NotEmpty(message = "PASSWORD cannot be Empty")
	private String pass;

	private int enabled;

	private String approvalStatus;

	@NotEmpty(message = "EMAIL ADDRESS cannot be Empty")
	@Email(message = "Enter A Valid Email Format")
	private String emailAddress;

	private long contactNumber;

	@ManyToOne
	@JoinColumn(name = "Role")
	private PFinnRole userRolePojo;

	public String getInterestArea() {
		return interestArea;
	}

	public void setInterestArea(String interestArea) {
		this.interestArea = interestArea;
	}

	public long getUserID() {
		return userID;
	}

	public void setUserID(long userID) {
		this.userID = userID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public PFinnRole getUserRolePojo() {
		return userRolePojo;
	}

	public void setUserRolePojo(PFinnRole userRolePojo) {
		this.userRolePojo = userRolePojo;
	}

}
