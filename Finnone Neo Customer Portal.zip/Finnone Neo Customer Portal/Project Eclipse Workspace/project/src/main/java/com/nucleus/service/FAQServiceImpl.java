package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.FAQDao;
import com.nucleus.pojo.FAQ;

@Service
public class FAQServiceImpl implements FAQService {

	@Autowired
	FAQDao faqDao;

	@Transactional(readOnly=false)
	@Override
	public void saveFAQ(FAQ faq) {
		faqDao.saveFAQ(faq);
	}

	@Transactional(readOnly=true)
	@Override
	public List<FAQ> getAllFAQ() {
		return faqDao.getAllFAQ();
	}

	@Override
	public List<FAQ> getFilteredFAQ(String searchString) {
		return faqDao.getFilteredFAQ(searchString);
	}
	
	
}
