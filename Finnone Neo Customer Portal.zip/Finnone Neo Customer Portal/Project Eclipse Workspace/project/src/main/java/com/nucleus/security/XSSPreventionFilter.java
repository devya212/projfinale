package com.nucleus.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Filters Http requests and removes malicious characters/strings
 * (i.e. XSS) from the Query String
 * @applied by Avinash Pathak
 * @modified by Mukesh Dewangan
 * @since 5 december 2018
 */
@WebFilter(urlPatterns={"/*"})
public class XSSPreventionFilter implements Filter {

	@Override
	public void destroy() {
		System.out.println("XSSPreventionFilter: destroy()");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		XSSRequestWrapper wrapper = new XSSRequestWrapper((HttpServletRequest)request);
		if (!((HttpServletRequest)request).getMethod().equalsIgnoreCase("POST") ) 
		{
			HTMLFilterRequestWrapper htmlFilterRequestwrapper = new HTMLFilterRequestWrapper(wrapper);
			chain.doFilter(htmlFilterRequestwrapper, response);
		}
		else
			chain.doFilter(wrapper, response);

		
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("XSSPreventionFilter: init()");
	}
}