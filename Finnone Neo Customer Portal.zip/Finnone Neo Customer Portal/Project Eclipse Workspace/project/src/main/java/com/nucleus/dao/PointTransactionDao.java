package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.Badge;
import com.nucleus.pojo.Gifts;
import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.pojo.UserReward;
import com.nucleus.pojo.UserTransaction;

public interface PointTransactionDao {
	public List<UserTransaction> getWithdrawalPoints(long userId);

	public List<PFinnUserContribution> fetch();

	public int fetchRewardPointsFromEventMaster(PFinnUserContribution contribution);

	public void saveToTransactionTable(UserTransaction transaction);

	public List<UserTransaction> getDepositPoints(long userId);

	public int totalContribution(long userId);

	public long fetchUserId(String username);

	public void pushToRewardTable(UserReward userReward);

	public UserReward fetchRewardTable(long userId);

	public List<UserTransaction> fetchTransactionTable(long userId);

	public List<PFinnUserContribution> fetchNewTransaction();

	public int totalFeedback(long userId);

	public int totalSuggestions(long userId);

	public int totalNewIdeas(long userId);

	public Gifts getGiftPoints(String giftName);

	public Badge getBadge(int rewardPoints);

}
