package com.nucleus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.News;
import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.service.ArticleService;
import com.nucleus.service.UserService;
import com.nucleus.utility.PFinnUserArticleFormAdminView;
import com.nucleus.utility.PFinnUserContributionsFormAdminView;
import com.nucleus.utility.PointsManagement;


/**
 * This controller will show all the news and show all feedbacks, suggestions
 * given by user. It will also provide the method to approve the feedbacks and
 * suggestions given by users.
 */

@Controller
public class AdminController {

	@Autowired
	PointsManagement pointsManagement;

	@Autowired
	UserService userService;
	
	@Autowired
	ArticleService articleService;

	@RequestMapping("/newNews")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView admin() {
		return new ModelAndView("newNews", "addNews", new News());

	}

	/**
	 * @author Mukesh Dewangan
	 * @since 01 October 2018
	 * @return This function will show the all of the user contribution that is not accepted
	 */
	@RequestMapping("/usercontri")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView usercontibution() {
		ModelAndView modelAndView = new ModelAndView("AdminView");
		modelAndView.addObject("pFinnUserContributionsForm",
				new PFinnUserContributionsFormAdminView(userService.serviceViewAll()));
		modelAndView.addObject("categoryRatingList", userService.getCategoryRatings());
		modelAndView.addObject("eventNames",userService.category());
		return modelAndView;

	}

	
	/**
	 * @author Mukesh Dewangan
	 * @since 02 October 2018
	 * @return This function will update the all of the user contribution that is not accepted.
	 *		Such that it will change the status of the user contribution and its feedback type.  
	 */
	@RequestMapping(value = "/feedbackUpdateAdmin", method = RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String feedbackUpdateAdmin(PFinnUserContributionsFormAdminView pFinnUserContributionsFormAdminView) {
		if(pFinnUserContributionsFormAdminView.getpFinnUserContributionsList()!=null)
		{
		userService.updateUserContributionsList(pFinnUserContributionsFormAdminView.getpFinnUserContributionsList());
		for (PFinnUserContribution pFinnUserContribution : pFinnUserContributionsFormAdminView
				.getpFinnUserContributionsList()) {
			if (pFinnUserContribution.getStatus() != null
					&& pFinnUserContribution.getStatus().equalsIgnoreCase("APPROVED"))
				pointsManagement.transaction();
		}
		return "redirect:/usercontri";
		}
		else
			return "redirect:/usercontri";
	}

	/**
	 * @author Vishal Talwar
	 * @since September 2018
	 * 
	 * This Function Fetches All "not Approved"/new Users List And give it to
	 * Admin to Approve
	 **/

	@RequestMapping(value = "/approveNewUserList")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView approveNewUserList() {
		List<PFinnNewUser> notApprovedUsers = userService.readNotApprovedUsersFromDB();
		for (PFinnNewUser a : notApprovedUsers) {
			System.out.println(a.getUsername());
		}
		return new ModelAndView("toBeApprovalList", "notApprovedUsers", notApprovedUsers);
	}

	/**  
	 *  @author Vishal Talwar
	 * @since September 2018
	 * 
	 * This Function helps to Approve new User on the basis of User ID
	 * **/

	@RequestMapping(value = "/approveNewUser/{userIdToBeApproved}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String approveNewUser(@PathVariable("userIdToBeApproved") String userIdToBeApproved) {
		userService.approveNewUser(userIdToBeApproved);
		return "redirect:/approveNewUserList";
	}
	
	/**  
	 *  @author Deepak Sharma
	 * @since September 2018
	 * 
	 * This Function helps to Reject new User on the basis of User ID
	 * **/

	@RequestMapping(value = "/rejectNewUser/{userIdToBeApproved}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String notApproved(@PathVariable("userIdToBeApproved") int userId) {
		System.out.println(userId + "......................................................................dd");

		userService.deniedApproval(userId);
		return "redirect:/approveNewUserList";

	}

	/**  
	 *  @author Vasu Sharma, Ajita Mittal
	 * 	@return : It will open the list of articles which are pending for approval/rejection by admin
	 * **/

	@RequestMapping("/approveArticle")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView approveArticle() {
		ModelAndView modelAndView = new ModelAndView("ApproveUserArticles");
		modelAndView.addObject("pFinnUserContributionArticleForm",
				new PFinnUserArticleFormAdminView(articleService.getAllPendingArticles()));
		return modelAndView;

	}

	/**  
	 *  @author Vasu Sharma, Ajita Mittal
	 *  @param 	1> Model attribute - pFinnUserArticleFormAdminView (PFinnUserArticleFormAdminView)
	 * 	@return : It will update the list of articles which are pending for approval/rejection by admin by removing 
	 * 			  those articles which are either approved or rejected and redirect to
	 * 			  the list of articles which are pending for approval/rejection by admin
	 * **/

	@RequestMapping("/articleUpdateAdmin")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public String articleUpdateAdmin(PFinnUserArticleFormAdminView pFinnUserArticleFormAdminView) {
		if(pFinnUserArticleFormAdminView.getPfinnContributeArticlesList()!=null)
		{
		articleService.updateUserContributionArticleList(pFinnUserArticleFormAdminView.getPfinnContributeArticlesList());
		return "redirect:/approveArticle";
		}
		else
			return "redirect:/approveArticle";
	}


}
