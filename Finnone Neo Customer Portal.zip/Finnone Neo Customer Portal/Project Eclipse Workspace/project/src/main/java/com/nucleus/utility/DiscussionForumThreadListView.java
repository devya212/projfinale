package com.nucleus.utility;

import com.nucleus.pojo.DiscussionPost;
import com.nucleus.pojo.DiscussionThread;

/**
 * @author Mukesh Dewangan
 * @since 20 September 2018
 * It will be used to show discussion thread list view
 */
public class DiscussionForumThreadListView {
	private DiscussionThread discussionThread;
	private DiscussionPost lastPost;
	private int totalNoOfApprovedPost;

	public DiscussionForumThreadListView() {
		super();
	}

	public DiscussionForumThreadListView(DiscussionThread discussionThread, DiscussionPost lastPost,
			int totalNoOfApprovedPost) {
		super();
		this.discussionThread = discussionThread;
		this.lastPost = lastPost;
		this.totalNoOfApprovedPost = totalNoOfApprovedPost;
	}

	public DiscussionThread getDiscussionThread() {
		return discussionThread;
	}

	public void setDiscussionThread(DiscussionThread discussionThread) {
		this.discussionThread = discussionThread;
	}

	public DiscussionPost getLastPost() {
		return lastPost;
	}

	public void setLastPost(DiscussionPost lastPost) {
		this.lastPost = lastPost;
	}

	public int getTotalNoOfApprovedPost() {
		return totalNoOfApprovedPost;
	}

	public void setTotalNoOfApprovedPost(int totalNoOfApprovedPost) {
		this.totalNoOfApprovedPost = totalNoOfApprovedPost;
	}

	@Override
	public String toString() {
		return "DiscussionForumThredListView [discussionThread=" + discussionThread + ", lastPost=" + lastPost
				+ ", totalNoOfApprovedPost=" + totalNoOfApprovedPost + "]";
	}
}
