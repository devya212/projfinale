package com.nucleus.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.Quiz;
import com.nucleus.pojo.QuizCheck;
import com.nucleus.service.CategoryService;
import com.nucleus.service.QuizService;

/**
 * @author Vishal Talwar, Deepak Sharma
 * @since October 2018
 */
@Controller
public class QuizController {
	@Autowired
	QuizService quizService;

	@Autowired
	CategoryService categoryService;

	
	@RequestMapping(value = "/quiz")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView quiz() {
		List<Quiz> quiz = quizService.allQuestions();
		return new ModelAndView("allQuestions", "quiz", quiz);
	}

	@RequestMapping(value = "/operation")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView operation(@RequestParam(value = "delete", required = false) String delete,
			@RequestParam(value = "add", required = false) String add) {

		if (add != null) {

			return new ModelAndView("addquiz", "ques", new Quiz());
		}
		if (delete != null) {
			List<Quiz> quiz = quizService.allQuestions();

			return new ModelAndView("deleteQuestion", "quiz", quiz);
		} else {
			return null;
		}

	}

	@RequestMapping(value = "/addques")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView addques(@Valid @ModelAttribute("ques") Quiz submit, BindingResult result , HttpServletRequest request) {
		if (result.hasErrors()) {
			return new ModelAndView("addquiz");
		} else {
			quizService.addques(submit);

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "success");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/quiz',true");
			return model;
		}
	}

	@RequestMapping(value = "/deleteQuestions")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView deleteQuestions(@RequestParam(value = "questionids", required = false) String questionids , HttpServletRequest request) {

		// System.out.println(questionids);
		if (questionids != null) {
			List<Quiz> questionList = new ArrayList<Quiz>();

			for (String questionid : questionids.split(",")) {
				Quiz question = new Quiz();
				question.setQuestionid(Integer.parseInt(questionid));
				questionList.add(question);

			}

			System.out.println("divy" + questionList);
			quizService.deleteQuestions(questionList);
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Success");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/quiz',true;");
			return model;

		} else {

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "please select a question");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/quiz',true;");
			return model;
		}
	}

	@RequestMapping(value = "/updateques/{name}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateques(@PathVariable("name") int questionid) {
		System.out.println("as....." + questionid);

		Quiz quiz = quizService.fetchquestion(questionid);
		System.out.println("as....." + quiz);
		return new ModelAndView("updatequiz", "quiz", quiz);
	}

	@RequestMapping(value = "/saveupdatedques")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView saveupdatedques(@ModelAttribute("quiz") Quiz submit , HttpServletRequest request) {
		
		quizService.addques1(submit);
		ModelAndView model = new ModelAndView("alert");
		model.addObject("alertMessage", "Success");
		model.addObject("location", "document.location.href = '"+request.getContextPath()+"/quiz',true;");
		return model;
		}

	@RequestMapping(value = "/startQuiz")
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView startQuiz() {
		return new ModelAndView("instruction","quizCategory",categoryService.getCategoryForQuiz());
	}
	
	@RequestMapping(value = "/start/{categoryName}")
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView start1(@PathVariable("categoryName") String categoryName, Principal principal, Model m) {
		
		List<QuizCheck> quizCheck = quizService.checkQuizStatus(principal.getName());
	/*	if (quizCheck.size() == 0) {*/
			if (quizCheck.isEmpty()) {
			List<Quiz> quiz = quizService.randomQuestion(categoryName.toUpperCase());
			quizService.storeQuestionsForChecking(quiz, principal.getName());
			m.addAttribute("userName", principal.getName());
			return new ModelAndView("quizRandomQuestions", "quiz", quiz);
		} else {
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Test is already Started");
			model.addObject("location", "window.close();");
			return model;
		}

	}

	/**
	 * @author Vishal Talwar
	 * @since October 2018
	 */

	@RequestMapping(value = "/answerSubmit", method = RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_USER')")

	public ModelAndView answerCheck(@RequestParam(value = "question1", required = false) String answer1,
			@RequestParam(value = "question2", required = false) String answer2,
			@RequestParam(value = "question3", required = false) String answer3,
			@RequestParam(value = "question4", required = false) String answer4,
			@RequestParam(value = "question5", required = false) String answer5, Model m, Principal principal) {
		int unansweredQuestions = 0;
		// List<QuizCheck>
		// quiz=quizService.checkQuizStatus(principal.getName());
		List<QuizCheck> quizCheck = new ArrayList<QuizCheck>();

		if (answer1 == null) {
			unansweredQuestions++;
		} else {
			QuizCheck check = new QuizCheck();
			String[] partsa = answer1.split("~", 3);
			check.setQuizQuestionId(Integer.parseInt(partsa[0]));
			check.setCorrectAnswer(partsa[2]);
			check.setUserName(partsa[1]);
			quizCheck.add(check);
		}
		if (answer2 == null) {
			unansweredQuestions++;
		} else {
			QuizCheck check = new QuizCheck();
			String[] partsb = answer2.split("~", 3);
			check.setQuizQuestionId(Integer.parseInt(partsb[0]));
			check.setCorrectAnswer(partsb[2]);
			check.setUserName(partsb[1]);
			quizCheck.add(check);
		}
		if (answer3 == null) {
			unansweredQuestions++;
		} else {
			QuizCheck check = new QuizCheck();
			String[] partsc = answer3.split("~", 3);
			check.setQuizQuestionId(Integer.parseInt(partsc[0]));
			check.setCorrectAnswer(partsc[2]);
			check.setUserName(partsc[1]);
			quizCheck.add(check);
		}
		if (answer4 == null) {
			unansweredQuestions++;
		} else {
			QuizCheck check = new QuizCheck();
			String[] partsd = answer4.split("~", 3);
			check.setQuizQuestionId(Integer.parseInt(partsd[0]));
			check.setCorrectAnswer(partsd[2]);
			check.setUserName(partsd[1]);
			quizCheck.add(check);
		}
		if (answer5 == null) {
			unansweredQuestions++;
		} else {
			QuizCheck check = new QuizCheck();
			String[] partse = answer5.split("~", 3);
			check.setQuizQuestionId(Integer.parseInt(partse[0]));
			check.setCorrectAnswer(partse[2]);
			check.setUserName(partse[1]);
			quizCheck.add(check);
		}

		int correctAnswers = quizService.compareAnswer(quizCheck);
		quizService.deleteCheckedAnswers(principal.getName());
		m.addAttribute("marks", correctAnswers * 2);
		m.addAttribute("answeredQuestions", 5 - unansweredQuestions);
		m.addAttribute("incorrectAnswer", (5 - unansweredQuestions) - correctAnswers);
		m.addAttribute("unanswered", unansweredQuestions);
		m.addAttribute("correctAnswer", correctAnswers);
		return new ModelAndView("resultOfQuiz");
	}

}
