package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.Quiz;
import com.nucleus.pojo.QuizCheck;

public interface QuizDao {
	public List<Quiz> allQuestions();

	public void deleteQuestion(List<Quiz> questionList);

	public void addQues(Quiz submit);

	public Quiz fetchques(int questionid);

	public void addQues1(Quiz submit);

	public List<Quiz> randomQuestion(String quizArea);

	public void storeQuestionsForChecking(List<QuizCheck> questionList);

	public List<QuizCheck> checkQuizStatus(String UserName);

	public int compareAnswer(List<QuizCheck> quizCheck);

	public void deleteCheckedAnswers(String userName);

}
