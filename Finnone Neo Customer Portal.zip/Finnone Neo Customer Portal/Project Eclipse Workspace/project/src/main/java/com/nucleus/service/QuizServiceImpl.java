package com.nucleus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.QuizDao;
import com.nucleus.pojo.Quiz;
import com.nucleus.pojo.QuizCheck;

@Transactional
@Service
public class QuizServiceImpl implements QuizService

{
	@Autowired
	private QuizDao quizDao;

	@Override
	public List<Quiz> allQuestions() {

		List<Quiz> quiz = quizDao.allQuestions();
		System.out.println("dao..." + quiz);
		return quiz;
	}

	@Override
	public void deleteQuestions(List<Quiz> questionList) {
		quizDao.deleteQuestion(questionList);
	}

	@Override
	public void addques(Quiz submit) {
		submit.setCategory(submit.getCategory().toUpperCase());
		submit.setCorrectanswer(submit.getCorrectanswer().trim());
		submit.setOptiona(submit.getOptiona().trim());
		submit.setOptionb(submit.getOptionb().trim());
		submit.setOptionc(submit.getOptionc().trim());
		submit.setOptiond(submit.getOptiond().trim());
		submit.setQuestion(submit.getQuestion().trim());

		quizDao.addQues(submit);

	}

	@Override
	public Quiz fetchquestion(int questionid) {

		return quizDao.fetchques(questionid);
	}

	@Override
	public void addques1(Quiz submit) {
		quizDao.addQues1(submit);

	}

	@Override
	public List<Quiz> randomQuestion(String quizArea) {

		return quizDao.randomQuestion(quizArea);
	}

	@Override
	public void storeQuestionsForChecking(List<Quiz> QuestionList, String userName) {

		List<QuizCheck> quizCheckList = new ArrayList<QuizCheck>();

		for (Quiz ques : QuestionList) {
			QuizCheck quizCheck = new QuizCheck();
			System.out.println(ques.getQuestionid());
			quizCheck.setCorrectAnswer(ques.getCorrectanswer());
			quizCheck.setQuizQuestionId(ques.getQuestionid());
			quizCheck.setUserName(userName);
			quizCheckList.add(quizCheck);

		}
		quizDao.storeQuestionsForChecking(quizCheckList);

	}

	@Override
	public List<QuizCheck> checkQuizStatus(String userName) {
		return quizDao.checkQuizStatus(userName);

	}

	@Override
	public int compareAnswer(List<QuizCheck> quizCheck) {
		return quizDao.compareAnswer(quizCheck);
	}

	@Override
	public void deleteCheckedAnswers(String userName) {
		quizDao.deleteCheckedAnswers(userName);

	}

}
