package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.pojo.Gifts;
import com.nucleus.pojo.UserReward;
import com.nucleus.pojo.UserTransaction;
import com.nucleus.service.PointTransactionService;
import com.nucleus.utility.PointsManagement;

@Controller
public class PointTransactionController {

	// Transaction of points management system

	@Autowired
	PointTransactionService pservice;

	@Autowired
	PointsManagement management;

	public static long userId;

	UserTransaction transaction = new UserTransaction();

	UserReward reward = new UserReward();

	@RequestMapping(value = "balance") // Click on Balance Link
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView aPoints() {
		userId = management.getUserId();

		ModelAndView model = new ModelAndView("bal");
		model.addObject("apoints", pservice.fetchRewardTable(userId)); // Reward
																		// Table
																		// From
																		// Database
		model.addObject("transaction", management.changeTime(pservice.fetchTransactionTable(userId)));
		model.addObject("totalContri", pservice.totalContribution(userId));
		model.addObject("totalFeed", pservice.totalFeedback(userId));
		model.addObject("totalSuggestions", pservice.totalSuggestions(userId));
		model.addObject("totalNewIdeas", pservice.totalNewIdeas(userId));
		// model.addObject("transaction",
		// pservice.fetchTransactionTable(userId));
		return model;
	}

	// ===========================================================================================================================

	@RequestMapping(value = "/redeem/{var}")
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView redeemPoints(@PathVariable("var") String gift) {
		System.out.println("inside redeem");
		userId = management.getUserId();
		management.transaction();
		Gifts gifts = pservice.getGiftPoints(gift);
		if (gifts.getGiftPoints() <= management.calculateAvailablePoints(userId)) {
			management.redeem(gifts.getGiftPoints(), userId);
			return new ModelAndView("Message", "msg", "Successfully Done!!");
		} else {
			return new ModelAndView("Message", "msg", "Not enough Points");
		}

	}

	@RequestMapping(value = "redeem")
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView redeemPointsHome() {
		userId = management.getUserId();
		// pservice.newTransaction();
		// management.transaction();
		return new ModelAndView("redeem", "apoints", management.calculateAvailablePoints(userId));
	}

	@RequestMapping(value = "howTo")
	@PreAuthorize("hasRole('ROLE_USER')")
	public String howToEarn() {
		return "howToEarn";
	}

	@RequestMapping(value = "accountDetails") // Click on Balance Link
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView accountDetails() {
		userId = management.getUserId();

		ModelAndView model = new ModelAndView("accountDetails");

		model.addObject("transaction", management.changeTime(pservice.fetchTransactionTable(userId)));

		return model;
	}

	// ===========================================================================================================================
}
