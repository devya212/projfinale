package com.nucleus.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.nucleus.pojo.News;

@Repository
public class NewsDaoImpl implements NewsDao {

	@PersistenceContext
	EntityManager entityManager;

	public boolean writeToDB(News news) {
		entityManager.persist(news);
		return false;

	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<News> readFromDB() {
		ArrayList<News> allNews = (ArrayList<News>) entityManager
				.createQuery("from News where status='active' order by dateadded desc").getResultList();
		return allNews;

	}

	@Override
	public ArrayList<News> readHeadlineFromDB() {
		@SuppressWarnings("unchecked")
		ArrayList<News> allNewsHeadlines = (ArrayList<News>) entityManager
				.createQuery(" from News where status='active' order by dateadded desc").getResultList();
		return allNewsHeadlines;

	}

	@Override
	public int archiveFromDB(ArrayList<News> newsList) {
		int a = 0;
		for (int i = 0; i < newsList.size(); i++) {
			a = entityManager.createQuery("update News set status='archived' where newsid=:newsid ")
					.setParameter("newsid", newsList.get(i).getNewsid()).executeUpdate();
		}
		return a;

	}

	@Override
	public News fetchFromDBUsingId(int newsid) {

		return entityManager.find(News.class, newsid);
	}

	@Override
	public int writeUpdateToDB(final News news) {
		if (news.getNewsImage().isEmpty()) {
			int a = entityManager
					.createQuery(
							"update News set headline=:headline , content=:content ,dateadded=:dateadded where newsid=:newsid")
					.setParameter("newsid", news.getNewsid()).setParameter("headline", news.getHeadline())
					.setParameter("content", news.getContent()).setParameter("dateadded", news.getDateadded())
					.executeUpdate();
			return a;

		} else {

			int a = entityManager
					.createQuery(
							"update News set headline=:headline , content=:content ,newsimage=:image ,dateadded=:dateadded where newsid=:newsid")
					.setParameter("headline", news.getHeadline()).setParameter("content", news.getContent())
					.setParameter("image", news.getNewsImage()).setParameter("dateadded", news.getDateadded())
					.setParameter("newsid", news.getNewsid()).executeUpdate();
			return a;

		}
	}

	@Override
	public ArrayList<News> readHeadlineFromDB1() {
		@SuppressWarnings("unchecked")
		ArrayList<News> allNewsHeadlines = (ArrayList<News>) entityManager
				.createQuery(" from News where status='archived' order by dateadded desc").getResultList();
		return allNewsHeadlines;

	}

	@Override
	public int unarchiveFromDB1(ArrayList<News> newsList) {

		int a = 0;
		for (int i = 0; i < newsList.size(); i++) {
			a = entityManager.createQuery("update News set status='active' where newsid=:newsid ")
					.setParameter("newsid", newsList.get(i).getNewsid()).executeUpdate();
		}

		return a;

	}

	@Override
	public News getPdf(int idOfPdfToBeDownloaded) {
		return entityManager.find(News.class, idOfPdfToBeDownloaded);

	}

}
