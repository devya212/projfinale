package com.nucleus.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

/**
 * @author Mukesh Dewangan
 * @since 18 November 2018
 * This filter extends the UsernamePasswordAuthenticationFilter So we can modify its all method for authentication
 */
public class CustomUsernamePasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will set the authentication manger in the UsernamePasswordAuthenticationFilter.
	 */
	@Override
	@Qualifier(value="authenticationManager")
	@Autowired
	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
	    super.setAuthenticationManager(authenticationManager);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will set the auth success handler in the UsernamePasswordAuthenticationFilter.
	 */
	@Override
	@Qualifier(value="authSuccessHandler")
	@Autowired
	public void setAuthenticationSuccessHandler(AuthenticationSuccessHandler successHandler) {
	    super.setAuthenticationSuccessHandler(successHandler);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will set the auth failure handler in the UsernamePasswordAuthenticationFilter.
	 */
	@Override
	@Qualifier(value="authFailureHandler")
	@Autowired
	public void setAuthenticationFailureHandler(AuthenticationFailureHandler failureHandler) {
	    super.setAuthenticationFailureHandler(failureHandler);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will set the session authentication strategy in the UsernamePasswordAuthenticationFilter.
	 */
	@Override
	public void setSessionAuthenticationStrategy(SessionAuthenticationStrategy sessionStrategy) {
		super.setSessionAuthenticationStrategy(sessionStrategy);
	}
	

	/**
	 * @author Mukesh Dewangan
	 * @since 18 November 2018
	 * This method will change the received request using UsernamePasswordAuthenticationRequestWrapper and pass it on. After changing request it will attempt for authentication.
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
		return super.attemptAuthentication(new UsernamePasswordAuthenticationRequestWrapper(request), response);
	} 
}
