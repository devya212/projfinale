package com.nucleus.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnUserContribution;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void newMember(PFinnNewUser up) {

		entityManager.merge(up);

	}

	
	@Override
	public int existance(PFinnNewUser userPojo) {
		int i = 0;
		Query query = entityManager.createQuery("select c from PFinnNewUser c where username=:name");
		query.setParameter("name", userPojo.getUsername());
		try {
			query.getSingleResult();
			i++;
		} catch (NoResultException exception) {
			Query query1 = entityManager.createQuery("select c from PFinnNewUser c where emailaddress=:email");
			query1.setParameter("email", userPojo.getEmailAddress());
			try {
				query1.getSingleResult();
				i++;
			} catch (NoResultException excpetion1) {
				i = 0;
			}
		}
		return i;
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param String-
	 *            userName
	 * @return PFinnNewUser - single user object It will give user object from
	 *         the database by username.
	 */
	@Override
	public PFinnNewUser getUserByUserName(String userName) {
		Query query = entityManager.createQuery("from PFinnNewUser where username=:userName");
		query.setParameter("userName", userName);
		query.setMaxResults(1);
		PFinnNewUser user = (PFinnNewUser) query.getResultList().get(0);
		return user;
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param PFinnNewUser
	 *            - single user object
	 * @return void It will store the userContribution object in the database.
	 */
	@Override
	public void save(PFinnUserContribution pFinnUserContribution) {
		entityManager.persist(pFinnUserContribution);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param none
	 * @return Map<String, String> - It is a map object of event where key is
	 *         eventType and value is eventFullName It will give Map object of
	 *         event<eventType, eventFullName
	 */
	@Override
	public Map<String, String> category() {
		Map<String, String> eventNameList = new HashMap<String, String>();
		@SuppressWarnings("unchecked")
		List<Object[]> eventList = entityManager
				.createQuery("select distinct eventType, eventFullName from EventMaster").getResultList();
		for (Object[] o : eventList)
			eventNameList.put((String) o[0], (String) o[1]);

		return eventNameList;
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param none
	 * @return List<String> - It is a list object of rating name like Moderate,
	 *         Simple, Complex It will give list object of all rating types for
	 *         user contribution approval
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<String> getCategoryRatings() {
		return entityManager.createQuery("select distinct rating from EventMaster").getResultList();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param none
	 * @return List<PFinnUserContribution> - It is a list object of
	 *         PFinnUserContribution whose status is null It will give list
	 *         object of all user contribution which is not approved by admin.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<PFinnUserContribution> viewAll() {
		return entityManager.createQuery("from PFinnUserContribution where status IS NULL").getResultList();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 * @param List<PFinnUserContribution>
	 *            - It is a list object of PFinnUserContribution whose status is
	 *            changed
	 * @return null It will update status of user contribution to APPROVED which
	 *         is approved by admin.
	 */
	@Override
	public void updateUserContributionsList(List<PFinnUserContribution> pFinnUserContributionsList) {
		for (PFinnUserContribution pFinnUserContribution : pFinnUserContributionsList) {
			PFinnUserContribution pFinnUserContributionObject = entityManager.find(PFinnUserContribution.class,
					pFinnUserContribution.getEventId());
			pFinnUserContributionObject.setEventType(pFinnUserContribution.getEventType());
			pFinnUserContributionObject.setStatus(pFinnUserContribution.getStatus());
			pFinnUserContributionObject.setRating(pFinnUserContribution.getRating());
			pFinnUserContributionObject.setRemark(pFinnUserContribution.getRemark());
			pFinnUserContributionObject.setStatusDate(pFinnUserContribution.getStatusDate());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PFinnNewUser> readNotApprovedUsersFromDB() {
		Query query = entityManager.createQuery("from PFinnNewUser where ApprovalStatus=?");
		query.setParameter(1, "not approved");
		return query.getResultList();

	}

	@Override
	public void approveNewUser(String userIdToBeApproved) {
		// System.out.println(Long.parseLong(userIdToBeApproved));
		Query query = entityManager.createQuery(
				"update PFinnNewUser set approvalstatus='approved' where userID='" + userIdToBeApproved.trim() + "'");
		query.executeUpdate();

	}

	@Override
	public PFinnNewUser checkApprovalStatus(String userNameToBeChecked) {
		Query query = entityManager
				.createQuery("from PFinnNewUser where username='" + userNameToBeChecked.trim() + "'");
		PFinnNewUser object = (PFinnNewUser) query.getSingleResult();
		return object;

	}

	@Override
	public void deniedApproval(int userId) {
		Query query = entityManager.createQuery("delete from PFinnNewUser where  userID=" + userId);
		query.executeUpdate();

	}
}
