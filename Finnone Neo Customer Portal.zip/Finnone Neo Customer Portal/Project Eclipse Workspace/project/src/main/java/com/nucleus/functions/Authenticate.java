package com.nucleus.functions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;

public class Authenticate extends SavedRequestAwareAuthenticationSuccessHandler {

	@Override
	protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response) {
		// *******************Get the role of logged in
		// user***********************
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String role = auth.getAuthorities().toString();
		
		HttpSession session = request.getSession(false);
		
		if(session != null)
		{
			session.removeAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
		}

		String targetUrl = "";
		if (role.contains("ROLE_USER")) {
			targetUrl = "/home";
		} else if (role.contains("ROLE_ADMIN")) {
			targetUrl = "/adminHome";
		}
		return targetUrl;
	}

}
