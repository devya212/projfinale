package com.nucleus.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.nucleus.pojo.Quiz;
import com.nucleus.pojo.QuizCheck;

@Repository
public class QuizDaoImpl implements QuizDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> allQuestions() {
		Query query = entityManager.createQuery("from Quiz");
		System.out.println("in dao... " + query);
		return query.getResultList();

	}

	@Override
	public void deleteQuestion(List<Quiz> questionList) {
		for (Quiz ques : questionList)

			entityManager.remove(entityManager.contains(ques) ? ques : entityManager.merge(ques));

	}

	@Override
	public void addQues(Quiz submit) {
		entityManager.persist(submit);

	}

	@Override
	public Quiz fetchques(int questionid) {

		Query query = entityManager.createQuery("from Quiz where QUESTIONID=?");

		query.setParameter(1, questionid);
		Quiz quiz = (Quiz) query.getSingleResult();
		return quiz;

	}

	@Override
	public void addQues1(Quiz submit) {
		/*
		 * Quiz quiz=fetchques(submit.getQuestionid());
		 */ /*
			 * Quiz quiz=new Quiz(); quiz.setQuestionid(submit.getQuestionid());
			 * quiz.setQuestion(submit.getQuestion());
			 * quiz.setOptiona(submit.getOptiona());
			 * quiz.setOptionb(submit.getOptionb());
			 * quiz.setOptionc(submit.getOptionc());
			 * quiz.setOptiond(submit.getOptiond());
			 * quiz.setCorrectanswer(submit.getCorrectanswer());
			 */
		entityManager.merge(submit);

	}

	@Override
	public List<Quiz> randomQuestion(String quizArea) {
		return jdbcTemplate.query("select * from pfinnquiz where category='" + quizArea.toUpperCase()
				+ "'order by dbms_random.value FETCH FIRST 5 ROWS ONLY", new ResultSetExtractor<List<Quiz>>() {
					@Override
					public List<Quiz> extractData(ResultSet rs) throws SQLException, DataAccessException {

						List<Quiz> list = new ArrayList<Quiz>();
						while (rs.next()) {
							Quiz quiz = new Quiz();
							quiz.setQuestionid(rs.getInt(1));
							quiz.setCorrectanswer(rs.getString(2));
							quiz.setQuestion(rs.getString(7));
							quiz.setOptiona(rs.getString(3));
							quiz.setOptionb(rs.getString(4));
							quiz.setOptionc(rs.getString(5));
							quiz.setOptiond(rs.getString(6));
							list.add(quiz);
						}
						return list;
					}
				});

	}

	@Override
	public void storeQuestionsForChecking(List<QuizCheck> questionList) {
		System.out.println(questionList);
		for (QuizCheck ques : questionList) {
			entityManager.merge(ques);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<QuizCheck> checkQuizStatus(String userName) {

		Query query = entityManager.createQuery("select c from QuizCheck c where userName=:name order by quizCheckId");
		query.setParameter("name", userName);
		return query.getResultList();

	}

	@Override
	public int compareAnswer(List<QuizCheck> quizCheck) {
		List<QuizCheck> matchedAnswers = new ArrayList<QuizCheck>();

		for (QuizCheck compare : quizCheck) {
			System.out.println("==============================");
			System.out.println(compare.getCorrectAnswer());
			System.out.println("==============================");
			Query query = entityManager.createQuery(
					"from QuizCheck where quizquestionid=:questionid and correctAnswer=:answer and username=:name");
			query.setParameter("questionid", compare.getQuizQuestionId());
			query.setParameter("answer", compare.getCorrectAnswer());
			query.setParameter("name", compare.getUserName());
			try {
				matchedAnswers.add((QuizCheck) query.getSingleResult());
			} catch (NoResultException ex) {

			}
		}
		for (QuizCheck match : matchedAnswers) {
			System.out.println(match.getCorrectAnswer());
		}
		return matchedAnswers.size();
	}

	@Override
	public void deleteCheckedAnswers(String userName) {

		entityManager.createQuery("delete  from QuizCheck  where username=:name").setParameter("name", userName)
				.executeUpdate();

	}

}
