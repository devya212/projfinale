package com.nucleus.utility;

import java.util.List;

import com.nucleus.pojo.PFinnContributeArticle;

public class PFinnUserArticleFormAdminView {

	List<PFinnContributeArticle> pfinnContributeArticlesList;
	
	

	public PFinnUserArticleFormAdminView() {
		super();
	}

	public PFinnUserArticleFormAdminView(List<PFinnContributeArticle> pfinnContributeArticlesList) {
		super();
		this.pfinnContributeArticlesList = pfinnContributeArticlesList;
	}

	public List<PFinnContributeArticle> getPfinnContributeArticlesList() {
		return pfinnContributeArticlesList;
	}

	public void setPfinnContributeArticlesList(List<PFinnContributeArticle> pfinnContributeArticlesList) {
		this.pfinnContributeArticlesList = pfinnContributeArticlesList;
	}
	
	
	
}
