package com.nucleus.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.pojo.DiscussionPost;
import com.nucleus.pojo.DiscussionThread;
import com.nucleus.pojo.DiscussionThreadCategory;
import com.nucleus.pojo.PFinnNewUser;

@Repository
public class DiscussionForumDaoImplementation implements DiscussionForumDao
{
	
	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param int - threadId: accept single integer threadId to fetch single discussion thread
	 * @return DiscussionThread : Single discussion thread object of given threadId
	 * This function will accept integer threadId and return DiscussionThreadObject
	 */
	@Override
	public DiscussionThread getDiscussionThreadByThreadId(int threadId) {
		return entityManager.find(DiscussionThread.class, threadId);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> DiscussionThread - discussionThread: Single discussion thread object
	 * 			2> int - pageNo: current page no to return the object for that page no
	 * 			3> int - perPageRecord: how many post should be selected from the database
	 * @return List<DiscussionPost> : List of post objects of given discussion thread according to given page no and per page record
	 * This function will accept discussion thread object, page no and per page record and shows post for 
	 * the given discussion thread according to given page no and per page record
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionPost> getApprovedDeletedPostsOfThread(DiscussionThread discussionThread, int pageNo, int perPageRecord) {
		Query query =  entityManager.createQuery("from DiscussionPost where discussionThread=:discussionThread and (status=:openStatus or status=:closeStatus) order by postedDate ASC", DiscussionPost.class);
		query.setParameter("discussionThread", discussionThread);
		query.setParameter("openStatus", "APPROVED");
		query.setParameter("closeStatus", "DELETED");
		query.setFirstResult((pageNo-1) * perPageRecord);
		query.setMaxResults(perPageRecord);
		return query.getResultList();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param DiscussionPost - discussionPost: accept single discussion post
	 * @return none 
	 * This function will accept single discussion post and store it in the database
	 */
	@Override
	public void postCommentOnThread(DiscussionPost discussionPost) {
		entityManager.persist(discussionPost);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param PFinnNewUser - pFinnNewUser: accept single pFinnNewUser object (Current loggedIn user)
	 * @return int - return total no of approved posts
	 * This function will accept single pFinnNewUser object (Current loggedIn user) and return total no of approved posts of given user (LoggedIn user)
	 */
	@Override
	public int getTotalNoOfApprovedPostOfUser(PFinnNewUser pFinnNewUser) {
		return Integer.parseInt(entityManager.createQuery("select count(*) from DiscussionPost where status=:status and postedByUser=:postedByUser")
		.setParameter("status", "APPROVED")
		.setParameter("postedByUser", pFinnNewUser)
		.getSingleResult().toString());
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param int - threadId: accept single discussion thread id
	 * @return none 
	 * This function will change the status of discussion thread in the database from OPEN->CLOSED / CLOSED->OPEN
	 */
	@Override
	public void changeDiscussionThreadStatus(int threadId) {
		DiscussionThread discussionThread = entityManager.find(DiscussionThread.class, threadId);
		if(discussionThread != null)
		{
			if(discussionThread.getThreadStatus().equalsIgnoreCase("OPEN"))
				discussionThread.setThreadStatus("CLOSED");
			else if(discussionThread.getThreadStatus().equalsIgnoreCase("CLOSED"))
				discussionThread.setThreadStatus("OPEN");
		}
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 10 October 2018
	 * @param int - postId: accept single discussion post id
	 * @return none 
	 * This function will accept single discussion post id and change its status to DELETED.
	 */
	@Override
	public void deletePost(int postId) {
		DiscussionPost discussionPost = entityManager.find(DiscussionPost.class, postId);
		if( (discussionPost != null) && (discussionPost.getStatus().equalsIgnoreCase("APPROVED")) )
		{
			discussionPost.setStatus("DELETED");
			discussionPost.setStatusTime(new Date(System.currentTimeMillis()));
		}
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 05 October 2018
	 * @param int - discussionPostId: accept single discussion post id
	 * @return DiscussionPost - discussionPost: return single discussion post 
	 * This function will accept single discussion post id and return it.
	 */
	@Override
	public DiscussionPost getDiscussionPostByDiscussionPostId(int discussionPostId) {
		return entityManager.find(DiscussionPost.class, discussionPostId);
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 24 September 2018
	 * @param 	1> DiscussionThreadCategory - discussionThreadCategory: accept single discussion thread category
	 * 			cases: 	a> when discussionThreadCategory is null then it will return discussion threads for all category
	 * 					b> when discussionThreadCategory is parent thread category then it will return all discussion thread of that category 
	 * 						and also child category of given thread category. If there is no threads then it will return empty list.
	 * 					c> when discussionThreadCategory is child thread category then it will return all discussion thread of particular that child category.
	 * 			2> String - order: order for posted-date ascending/descending
	 * 			cases:	a> when order is null then it select threads by default order
	 * 					b> when order is "newest" then it will return threads in descending order according to the postedDate
	 * 					c> when order is "oldest" then it will return threads in ascending order according to the postedDate
	 * 			3> int - pageNo:current page-no
	 * 			4> int - perPageRecord: per-page-record
	 * 			cases: if pageNo and perPageRecord is 0 then it will return all threads.
	 * @return List<DiscussionThread> - return list of discussion threads 
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of discussion threads with "OPEN" and "CLOSED" status.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionThread> getThreads(DiscussionThreadCategory discussionThreadCategory, String order, int pageNo, int perPageRecord) 
	{
		List<DiscussionThreadCategory> childCategoryList = null;
		
		StringBuilder queryString = new StringBuilder("from DiscussionThread where (threadStatus=:openStatus or threadStatus=:closeStatus)");
		
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				queryString.append(" and category=:discussionThreadCategory");
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				childCategoryList = this.getCategories(discussionThreadCategory.getCategoryId());
				if(!childCategoryList.isEmpty())
				{
					queryString.append(" and (");
					queryString.append(" category=:discussionThreadCategory_0");
					for(int i=1; i<childCategoryList.size(); ++i)
						queryString.append(" or category=:discussionThreadCategory_"+i);
					queryString.append(" )");
				}
				else if(childCategoryList.isEmpty())
					queryString.append(" and category=:discussionThreadCategory");
			}
		}
		
		
		if(order != null)
		{
			if(order.equalsIgnoreCase("newest"))
				queryString.append(" order by postedDate desc");
			else if(order.equalsIgnoreCase("oldest"))
				queryString.append(" order by postedDate asc");
		}
		
		
		Query query = entityManager.createQuery(queryString.toString())
		.setParameter("openStatus", "OPEN")
		.setParameter("closeStatus", "CLOSED");
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				if(childCategoryList != null && !childCategoryList.isEmpty())
				{
					for(int i=0; i<childCategoryList.size(); ++i)
						query = query.setParameter("discussionThreadCategory_"+i, childCategoryList.get(i));
				}
				else if(childCategoryList != null && childCategoryList.isEmpty())
					query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			}
		}		
		
		
		query = query.setFirstResult((pageNo-1) * perPageRecord)
		.setMaxResults(perPageRecord);
			
		return query.getResultList();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 30 December 2018
	 * @param 	1> DiscussionThreadCategory - discussionThreadCategory : accept thread category name
	 * 			cases: 	a> when discussionThreadCategory is null then it will return discussion threads for all category
	 * 					b> when discussionThreadCategory is parent thread category then it will return all discussion thread of that category 
	 * 						and also child category of given thread category. If there is no threads then it will return empty list.
	 * 					c> when discussionThreadCategory is child thread category then it will return all discussion thread of particular that child category.
	 * 			2> int - pageNo : current page-no
	 * 			3> int - perPageRecord : per-page-record
	 * 			cases: if pageNo and perPageRecord is 0 then it will return all threads.
	 * @return List<Integer> - return list of id of discussion threads sorted based on the no. post commented on each thread.
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of id of discussion threads with "OPEN" and "CLOSED" status sorted based on the no. post commented on each thread.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Integer> getTopThreads(DiscussionThreadCategory discussionThreadCategory, int pageNo, int perPageRecord) 
	{
		List<DiscussionThreadCategory> childCategoryList = null;
		
		StringBuilder queryString = new StringBuilder("select t.discussionThreadId from DiscussionPost p right join p.discussionThread t on p.status=:postStatus where (t.threadStatus=:openStatus or t.threadStatus=:closeStatus)");
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				queryString.append(" and t.category=:discussionThreadCategory");
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				childCategoryList = this.getCategories(discussionThreadCategory.getCategoryId());
				if(!childCategoryList.isEmpty())
				{
					queryString.append(" and (");
					queryString.append(" t.category=:discussionThreadCategory_0");
					for(int i=1; i<childCategoryList.size(); ++i)
						queryString.append(" or t.category=:discussionThreadCategory_"+i);
					queryString.append(" )");
				}
				else if(childCategoryList.isEmpty())
					queryString.append(" and t.category=:discussionThreadCategory");
			}
		}
		
		queryString.append(" group by t order by count(p) desc");
		
		
		Query query = entityManager.createQuery(queryString.toString(), Integer.class)
		.setParameter("postStatus", "APPROVED")
		.setParameter("openStatus", "OPEN")
		.setParameter("closeStatus", "CLOSED");
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				if(childCategoryList != null && !childCategoryList.isEmpty())
				{
					for(int i=0; i<childCategoryList.size(); ++i)
						query = query.setParameter("discussionThreadCategory_"+i, childCategoryList.get(i));
				}
				else if(childCategoryList != null && childCategoryList.isEmpty())
					query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			}
		}		
		
		query = query.setFirstResult((pageNo-1) * perPageRecord)
		.setMaxResults(perPageRecord);
		
		return query.getResultList();
	}
	
	/**
	 * @author Mukesh Dewangan
	 * @since 30 December 2018
	 * @param 	1> DiscussionThreadCategory - discussionThreadCategory : accept thread category name
	 * 			cases: 	a> when discussionThreadCategory is null then it will return discussion threads for all category
	 * 					b> when discussionThreadCategory is parent thread category then it will return all discussion thread of that category 
	 * 						and also child category of given thread category. If there is no threads then it will return empty list.
	 * 					c> when discussionThreadCategory is child thread category then it will return all discussion thread of particular that child category.
	 * 			2> int - pageNo : current page-no
	 * 			3> int - perPageRecord : per-page-record
	 * 			cases: if pageNo and perPageRecord is 0 then it will return all threads.
	 * @return List<Integer> - return list of id of discussion threads sorted based on the latest post commented on each thread.
	 * This function will accept single discussion thread category, order, current page-no and per-page-record and return list of id of discussion threads with "OPEN" and "CLOSED" status sorted based on the latest post commented on each thread.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Integer> getLatestThreads(DiscussionThreadCategory discussionThreadCategory, int pageNo, int perPageRecord) 
	{
		List<DiscussionThreadCategory> childCategoryList = null;
		
		StringBuilder queryString = new StringBuilder("select t.discussionThreadId from DiscussionPost p right join p.discussionThread t on p.status=:postStatus where (t.threadStatus=:openStatus or t.threadStatus=:closeStatus)");
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				queryString.append(" and t.category=:discussionThreadCategory");
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				childCategoryList = this.getCategories(discussionThreadCategory.getCategoryId());
				if(!childCategoryList.isEmpty())
				{
					queryString.append(" and (");
					queryString.append(" t.category=:discussionThreadCategory_0");
					for(int i=1; i<childCategoryList.size(); ++i)
						queryString.append(" or t.category=:discussionThreadCategory_"+i);
					queryString.append(" )");
				}
				else if(childCategoryList.isEmpty())
					queryString.append(" and t.category=:discussionThreadCategory");
			}
		}
		
		queryString.append(" group by t order by max(p.postedDate) desc nulls last");
		
		
		Query query = entityManager.createQuery(queryString.toString(), Integer.class)
		.setParameter("postStatus", "APPROVED")
		.setParameter("openStatus", "OPEN")
		.setParameter("closeStatus", "CLOSED");
		
		if(discussionThreadCategory != null)
		{
			if(discussionThreadCategory.getParentCategory() != null)
				query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			else if(discussionThreadCategory.getParentCategory() == null)
			{
				if(childCategoryList != null && !childCategoryList.isEmpty())
				{
					for(int i=0; i<childCategoryList.size(); ++i)
						query = query.setParameter("discussionThreadCategory_"+i, childCategoryList.get(i));
				}
				else if(childCategoryList != null && childCategoryList.isEmpty())
					query = query.setParameter("discussionThreadCategory", discussionThreadCategory);
			}
		}		
		
		query = query.setFirstResult((pageNo-1) * perPageRecord)
		.setMaxResults(perPageRecord);
			
		return query.getResultList();
	}

	//======================================================================================
	

	/**
	 * @author Vasu Sharma
	 * @since 24 September 2018
	 * @param discussionThread object reference with filled data by admin
	 */
	@Override
	public void createThread(DiscussionThread discussionThread) {
		entityManager.persist(discussionThread);
	}

	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param categoryId for which we want to get the discussion threads
	 * @return list of Discussion Threads  
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionThread> getThreadsByCategory(int categoryId) {

		// check for parent category
		if (entityManager
				.find(DiscussionThreadCategory.class, categoryId).getParentCategory() == null) {

			List<Integer> categoryIds = entityManager
					.createQuery("select categoryId from DiscussionThreadCategory where PARENTCATEGORY_CATEGORYID = :categoryId")
					.setParameter("categoryId", categoryId).getResultList();

			List<DiscussionThread> threads = new ArrayList<>();
			for (Integer id : categoryIds) {
				threads.addAll(entityManager.createQuery("from DiscussionThread where category_categoryId = :categoryId")
						.setParameter("categoryId", id).getResultList());
			}
			return threads;
		}

		// sub-category
		return entityManager.createQuery("from DiscussionThread where category_categoryId = :categoryId")
				.setParameter("categoryId", categoryId).getResultList();
	}
	
	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param categoryId for which we want to get the discussion threads
	 * @return list of Discussion Threads  
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionThread> getThreadsByCategory2(int categoryId) {

		// check for parent category
		if (entityManager
				.find(DiscussionThreadCategory.class, categoryId).getParentCategory() == null) {
			
			List<Integer> categoryIds = entityManager
					.createQuery("select categoryId from DiscussionThreadCategory where PARENTCATEGORY_CATEGORYID = :categoryId")
					.setParameter("categoryId", categoryId).getResultList();

			StringBuilder categoriesNamedParameterSeperatedWithComma = new StringBuilder("from DiscussionThread where category_categoryId in (");
			
			for (int i = 0; i < categoryIds.size(); i++) {
				categoriesNamedParameterSeperatedWithComma.append(":category_"+i+",");
			}
			categoriesNamedParameterSeperatedWithComma = categoriesNamedParameterSeperatedWithComma.replace(
					categoriesNamedParameterSeperatedWithComma.length() - 1
					, categoriesNamedParameterSeperatedWithComma.length()
					, "");
			categoriesNamedParameterSeperatedWithComma.append(") order by posteddate desc");
			
			Query query = entityManager.createQuery(categoriesNamedParameterSeperatedWithComma.toString());
			
			for (int i = 0; i < categoryIds.size(); i++) {
				query.setParameter("category_"+i, categoryIds.get(i));
				
			}
			
			return query.getResultList();
		}

		// sub-category
		return entityManager.createQuery("from DiscussionThread where category_categoryId = :categoryId order by posteddate desc")
				.setParameter("categoryId", categoryId).getResultList();
	}

	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param categoryId should be -1 for getting parent categories 
	 * 		  and specific categoryId for getting child categories (sub-categories) 
	 * @return list of Discussion Thread Category 
	 * 
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionThreadCategory> getCategories(int categoryId) {
		// all categories
		if (categoryId == -2) {
			return entityManager.createQuery("from DiscussionThreadCategory")
					.getResultList();
		}
				
		// categories
		if (categoryId == -1) {
			return entityManager.createQuery("from DiscussionThreadCategory where PARENTCATEGORY_CATEGORYID is null")
					.getResultList();
		}

		// sub-catgories
		return entityManager.createQuery("from DiscussionThreadCategory where PARENTCATEGORY_CATEGORYID = :categoryId")
				.setParameter("categoryId", categoryId).getResultList();
	}
	

	/**
	 * @author Vasu Sharma
	 * @since 25 September 2018
	 * @param PFinnNewUser user : User object  
	 * @param DiscussionThread discussionThread : Thread object ,
	 * 		 Add this user object to view list of discussionThread object.
	 */
	@Override
	public void addUserToViewListOfDiscussionThread(PFinnNewUser user, DiscussionThread discussionThread) {
		DiscussionThread mainDiscussionThread = entityManager.find(DiscussionThread.class, discussionThread.getDiscussionThreadId());
		List<PFinnNewUser> users = mainDiscussionThread.getUsersWhoHaveViewedThisThread();
		users.add(user);
		mainDiscussionThread.setUsersWhoHaveViewedThisThread(users);
	}

	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 * @param DiscussionThreadCategory discussionThreadCategory : save this discussion thread category in db
	 */
	@Override
	public void createDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory) {
		entityManager.persist(discussionThreadCategory);
	}

	/**
	 * @author Vasu Sharma
	 * @since 04 October 2018
	 * @param DiscussionThreadCategory discussionThreadCategory : update this discussion thread category in db
	 */
	@Override
	public void updateDiscussionThreadCategory(DiscussionThreadCategory discussionThreadCategory) {
		entityManager.merge(discussionThreadCategory);
	}
	
	//======================================================================================
	
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Fetching all data for the approval
	 * @return List of the DiscussionPost
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<DiscussionPost> viewAll() {
		
		return (List<DiscussionPost>) entityManager.createQuery("from DiscussionPost where status is null").getResultList();
	}
	
	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 * Updation of the data after the status update
	 */
	@Override
	public void updatePostStatus(List<DiscussionPost> discussionPostList) {
		for(DiscussionPost discussionPost: discussionPostList)
		{
			DiscussionPost discussionPostObject = entityManager.find(DiscussionPost.class, discussionPost.getDiscussionPostId());
			discussionPostObject.setStatus(discussionPost.getStatus());
			discussionPostObject.setRemarkForStatus(discussionPost.getRemarkForStatus());
			discussionPostObject.setStatusTime(discussionPost.getStatusTime());
		}
		
	}

	/**
	 * @author Ajita Mittal
	 * @since 25 September 2018
	 */
	@Override
	public DiscussionThreadCategory fetchByCategoryName(String categoryName) {
		return (DiscussionThreadCategory) entityManager.createQuery("from DiscussionThreadCategory where categoryName=:categoryName")
				.setParameter("categoryName", categoryName).getSingleResult();
	}
	/**
	 * @author Ajita Mittal
	 * @since 09 oct 2018
	 * @param Updated Discussion Thread
	 * Setting the updated value of the thread 
	 */
	@Override
	public void updateThread(DiscussionThread discussionThread) {
		DiscussionThread discussionThread1 = entityManager.find(DiscussionThread.class, discussionThread.getDiscussionThreadId());
		discussionThread1.setTitle(discussionThread.getTitle());
		discussionThread1.setDescription(discussionThread.getDescription());
		discussionThread1.setCategory(discussionThread.getCategory());
	}
	
	/**
	 * @author Ajita Mittal
	 * @since 23 November 2018
	 * @param Request Parameter - searchString (String)
	 * @return It will return the list of discussion threads according to the searched parameter.
	 */
	@Transactional
	@Override
	public List<DiscussionThread> searchDiscussionThreads(String searchString) {
		
		return entityManager.createQuery("select distinct t from DiscussionPost p right join p.discussionThread t"
				+ " where (t.threadStatus=:openStatus or t.threadStatus=:closeStatus) and"
				+ " (LOWER(t.title) like concat('%', LOWER(:searchString), '%') OR"
				+ " LOWER(t.description) like concat('%', LOWER(:searchString), '%') OR "
				+ "LOWER(p.postContent) like concat('%', LOWER(:searchString), '%') ) order by t.postedDate desc", DiscussionThread.class)
				.setParameter("openStatus", "OPEN")
				.setParameter("closeStatus", "CLOSED")
				.setParameter("searchString", searchString)
				.getResultList();
	}
	
	
	
	
	
	

	
//	===============================================Mukesh
	
	@Transactional
	@Override
	public List<DiscussionThreadCategory> test()
	{
		return entityManager.createQuery("from DiscussionThreadCategory where parentCategory.categoryId = :categoryId", DiscussionThreadCategory.class).setParameter("categoryId", 131).getResultList();
	}


}
