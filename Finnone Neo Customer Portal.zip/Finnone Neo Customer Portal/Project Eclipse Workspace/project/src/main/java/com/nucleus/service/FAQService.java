package com.nucleus.service;

import java.util.List;

import com.nucleus.pojo.FAQ;

public interface FAQService {

	public void saveFAQ(FAQ faq);

	public List<FAQ> getAllFAQ();

	public List<FAQ> getFilteredFAQ(String searchString);
}
