package com.nucleus.controller;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService userService;

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018 This method accept userContribution object and
	 *        save it to the database. userContribution object can be feedback,
	 *        suggestion and new idea.
	 */
	@RequestMapping(value = "/userSubmit", method = RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_USER')")
	public ModelAndView productSave(PFinnUserContribution pFinnUserContribution) {
		ModelAndView modelAndView = new ModelAndView("contributeArticleSuccess");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (!(authentication instanceof AnonymousAuthenticationToken)) {
			pFinnUserContribution.setpFinnNewUser(userService.getUserByUserName(authentication.getName()));
			pFinnUserContribution.setEventDate(new Date(System.currentTimeMillis()));

			userService.save(pFinnUserContribution);
		}
		return modelAndView;
	}

}