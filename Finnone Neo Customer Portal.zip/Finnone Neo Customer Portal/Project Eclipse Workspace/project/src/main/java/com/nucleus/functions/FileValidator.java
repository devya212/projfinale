package com.nucleus.functions;

import java.io.IOException;
import java.io.InputStream;

import org.apache.tika.detect.Detector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.AutoDetectParser;
import org.springframework.web.multipart.MultipartFile;

public class FileValidator 
{
public String fileValidator(InputStream is1,MultipartFile filePart) throws IOException
{
	
	AutoDetectParser parser1 = new AutoDetectParser();
	Detector detector1 = parser1.getDetector();
	Metadata metadata1 = new Metadata();
	TikaInputStream tikaInputStream1 = TikaInputStream.get(is1);
	metadata1.add(Metadata.RESOURCE_NAME_KEY,filePart.getOriginalFilename());
	MediaType mediaType1 = detector1.detect(tikaInputStream1, metadata1);
	 
	return mediaType1.toString();
	
}
}
