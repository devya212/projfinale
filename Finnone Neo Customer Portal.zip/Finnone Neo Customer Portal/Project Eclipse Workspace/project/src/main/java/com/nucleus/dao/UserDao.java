package com.nucleus.dao;

import java.util.List;
import java.util.Map;

import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnUserContribution;

public interface UserDao {
	public void newMember(PFinnNewUser up);

	public int existance(PFinnNewUser up);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public PFinnNewUser getUserByUserName(String userName);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public void save(PFinnUserContribution pFinnUserContribution);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public Map<String, String> category();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public List<PFinnUserContribution> viewAll();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public List<String> getCategoryRatings();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public void updateUserContributionsList(List<PFinnUserContribution> pFinnUserContributionsList);

	public List<PFinnNewUser> readNotApprovedUsersFromDB();

	public void approveNewUser(String userIdToBeApproved);

	public PFinnNewUser checkApprovalStatus(String userNameToBeChecked);

	public void deniedApproval(int userId);
}
