package com.nucleus.dao;

import java.util.List;

import com.nucleus.pojo.DiscussionThreadCategory;

public interface CategoryDao {

	public List<DiscussionThreadCategory> getCategoryForQuiz();
	
	

}
