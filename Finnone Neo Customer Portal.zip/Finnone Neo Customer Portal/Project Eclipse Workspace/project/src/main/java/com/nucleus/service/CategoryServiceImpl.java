package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.CategoryDao;
import com.nucleus.pojo.DiscussionThreadCategory;


@Transactional
@Service
public class CategoryServiceImpl implements CategoryService
{
@Autowired
private CategoryDao categoryDao;



	@Override
	public List<DiscussionThreadCategory> getCategoryForQuiz() {
		return categoryDao.getCategoryForQuiz();
		
	}

}
