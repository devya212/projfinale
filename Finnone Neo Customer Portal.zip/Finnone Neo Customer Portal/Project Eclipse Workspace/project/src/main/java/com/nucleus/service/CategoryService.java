package com.nucleus.service;

import java.util.List;

import com.nucleus.pojo.DiscussionThreadCategory;

public interface CategoryService 
{
public List<DiscussionThreadCategory> getCategoryForQuiz();
}
