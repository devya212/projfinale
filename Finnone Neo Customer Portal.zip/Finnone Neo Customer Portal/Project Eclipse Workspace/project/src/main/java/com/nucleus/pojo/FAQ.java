package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="pFinnFAQ")
@SequenceGenerator(sequenceName="faqSequenceGenerator", name="faqSequenceGenerator")
public class FAQ {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="faqSequenceGenerator")
	private int questionId;
	private String question;
	private String answer;
	
	public FAQ() {
		
	}
	
	public FAQ(String question, String answer) {
		this.question = question;
		this.answer = answer;
	}
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
