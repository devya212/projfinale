package com.nucleus.functions;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//******************this class helps in encoding password********************

public class PasswordEncoder {
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	public String encode(String a) {
		String hashedPass = passwordEncoder.encode(a);
		return hashedPass;
	}
}
