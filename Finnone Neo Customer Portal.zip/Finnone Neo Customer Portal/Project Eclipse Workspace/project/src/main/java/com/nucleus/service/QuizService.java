package com.nucleus.service;

import java.util.List;

import com.nucleus.pojo.Quiz;
import com.nucleus.pojo.QuizCheck;

public interface QuizService

{
	public List<Quiz> allQuestions();

	public void deleteQuestions(List<Quiz> QuestionList);

	public void addques(Quiz submit);

	public Quiz fetchquestion(int questionid);

	public void addques1(Quiz submit);

	public List<Quiz> randomQuestion(String quizArea);

	public void storeQuestionsForChecking(List<Quiz> QuestionList, String userName);

	public List<QuizCheck> checkQuizStatus(String userName);

	public int compareAnswer(List<QuizCheck> quizCheck);

	public void deleteCheckedAnswers(String userName);

}
