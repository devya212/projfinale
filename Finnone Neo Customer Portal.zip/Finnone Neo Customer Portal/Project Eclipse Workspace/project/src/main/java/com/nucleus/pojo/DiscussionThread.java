package com.nucleus.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * @author Vasu Sharma
 * @since 24 September 2018
 */

@Entity
@Table(name="PFinnDiscussionThread_temp1")
@SequenceGenerator(name="pfinnDiscussionThreadSequenceGenerator" , sequenceName="pfinnDiscussionThreadSequenceGenerator" ,initialValue=1)
public class DiscussionThread {
	@Id 
	@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="pfinnDiscussionThreadSequenceGenerator")
	private int discussionThreadId;
	@NotNull
	@Size(min=1)
	private String title;
//	@Type(type="text")
	private String description;
	@NotNull
	private Date postedDate;
	@NotNull
	@ManyToOne
	private PFinnNewUser postedByUser;
	@NotNull
	@ManyToOne
	private DiscussionThreadCategory category;
	@NotNull
	private String threadStatus;
	
	@ManyToMany(fetch=FetchType.EAGER)
	private List<PFinnNewUser> usersWhoHaveViewedThisThread = new ArrayList<>();

	
	//constructors

	public DiscussionThread() {
	}



	public DiscussionThread(int discussionThreadId, String title, String description, Date postedDate,
			PFinnNewUser postedByUser, DiscussionThreadCategory category, String threadStatus,
			List<PFinnNewUser> usersWhoHaveViewedThisThread) {
		super();
		this.discussionThreadId = discussionThreadId;
		this.title = title;
		this.description = description;
		this.postedDate = postedDate;
		this.postedByUser = postedByUser;
		this.category = category;
		this.threadStatus = threadStatus;
		this.usersWhoHaveViewedThisThread = usersWhoHaveViewedThisThread;
	}



	//getters and setters
	public int getDiscussionThreadId() {
		return discussionThreadId;
	}


	public void setDiscussionThreadId(int discussionThreadId) {
		this.discussionThreadId = discussionThreadId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getPostedDate() {
		return postedDate;
	}


	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}


	public PFinnNewUser getPostedByUser() {
		return postedByUser;
	}


	public void setPostedByUser(PFinnNewUser postedByUser) {
		this.postedByUser = postedByUser;
	}


	public DiscussionThreadCategory getCategory() {
		return category;
	}


	public void setCategory(DiscussionThreadCategory category) {
		this.category = category;
	}


	public String getThreadStatus() {
		return threadStatus;
	}


	public void setThreadStatus(String threadStatus) {
		this.threadStatus = threadStatus;
	}


	public List<PFinnNewUser> getUsersWhoHaveViewedThisThread() {
		return usersWhoHaveViewedThisThread;
	}



	public void setUsersWhoHaveViewedThisThread(List<PFinnNewUser> usersWhoHaveViewedThisThread) {
		this.usersWhoHaveViewedThisThread = usersWhoHaveViewedThisThread;
	}



	@Override
	public String toString() {
		return "DiscussionThread [discussionThreadId=" + discussionThreadId + ", title=" + title + ", description="
				+ description + ", postedDate=" + postedDate + ", postedByUser=" + postedByUser + ", category="
				+ category + ", threadStatus=" + threadStatus + ", usersWhoHaveViewedThisThread="
				+ usersWhoHaveViewedThisThread + "]";
	}

	
	
}
