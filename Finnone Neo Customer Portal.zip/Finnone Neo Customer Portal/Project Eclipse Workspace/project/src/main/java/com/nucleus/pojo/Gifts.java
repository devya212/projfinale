package com.nucleus.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "pfinngiftmaster")
@SequenceGenerator(name="pfinngiftmasterSequenceGenerator" , sequenceName="pfinngiftmasterSequenceGenerator" ,initialValue=1)

public class Gifts {

	@Id
	@GeneratedValue(generator="pfinngiftmasterSequenceGenerator" , strategy=GenerationType.SEQUENCE)
	private int giftId;
	private String giftName;
	private int giftPoints;
	private String giftDescription;

	public int getGiftId() {
		return giftId;
	}

	public void setGiftId(int giftId) {
		this.giftId = giftId;
	}

	public String getGiftName() {
		return giftName;
	}

	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}

	public int getGiftPoints() {
		return giftPoints;
	}

	public void setGiftPoints(int giftPoints) {
		this.giftPoints = giftPoints;
	}

	public String getGiftDescription() {
		return giftDescription;
	}

	public void setGiftDescription(String giftDescription) {
		this.giftDescription = giftDescription;
	}

}
