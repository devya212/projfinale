package com.nucleus.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.functions.FileValidator;
import com.nucleus.pojo.News;
import com.nucleus.service.NewsService;


/**
 *@author Vishal Talwar ,Abhishek Sharma ,Deepak Sharma 
 * @since September 2018
 * 
 **/
@MultipartConfig
@Controller
public class NewsController {
	@SuppressWarnings("unused")
	@Autowired
	private MultipartResolver multipartResolver;

	@Autowired
	private NewsService newsService;

	@RequestMapping(value = "/newNews", method = RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView newNews(
			@RequestBody @RequestParam("image") MultipartFile filePart,
			@RequestParam("headline") String headline,
			@RequestParam("content") String content,
			@RequestParam(value = "fileUpload", required = false) CommonsMultipartFile pdfFileUpload,
			@ModelAttribute("addNews") News news1, 
			HttpServletRequest request) throws IOException {

		
		
		
	
		/* source code of tika for image */
		InputStream is1 = filePart.getInputStream();
		FileValidator filevalidator=new FileValidator();
		String mediatype11=filevalidator.fileValidator(is1, filePart);
		String filetype = mediatype11.substring(0, 5);
		 
		System.out.println("the type of the image is++++++++++++++++++++++++++++++++++++++"+mediatype11);
		
		
		
		/* source code of tika for PDF FILE */
		InputStream is = pdfFileUpload.getInputStream();
		String mediaType=filevalidator.fileValidator(is, pdfFileUpload); 
		System.out.println("the type of the pdf is+++++++++++++++++++++++++++++++++++++"+mediaType);
		 
		
		
		
		if (filetype.equalsIgnoreCase("image")||mediatype11.equalsIgnoreCase("application/octet-stream")) {

			News news = new News();
			news.setHeadline(headline);
			news.setContent(content);
			news.setDateadded(new Date(System.currentTimeMillis()));
			news.setStatus("active");

			if (mediaType.equalsIgnoreCase("application/octet-stream")
					|| mediaType.equalsIgnoreCase("application/pdf")) {
				news.setPdffile(pdfFileUpload.getBytes());

			}

			else {
				ModelAndView model = new ModelAndView("alert");
				model.addObject("alertMessage", "please select a  pdf file");
				model.addObject("location",
						"document.location.href = '"+request.getContextPath()+"/newNews',true;");
				return model;
			}

			newsService.writeToDB(news, filePart);
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Success");
			model.addObject("location",
					"document.location.href = '"+request.getContextPath()+"/newNews',true;");
			return model;
		}

		else {
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "please select a valid image file");
			model.addObject("location",
					"document.location.href = '"+request.getContextPath()+"/newNews',true;");
			return model;
		}

	}

	@RequestMapping(value = "/viewAllNews")
	public ModelAndView allNews() {
		ArrayList<News> newsList = new ArrayList<News>();
		newsList = newsService.readFromDB();

		return new ModelAndView("Display", "newsList", newsList);

	}

	// ****************************************************************************************************//*
	@RequestMapping(value = "/viewAllNewsHeadlines")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView allNewsHeadine() {
		ArrayList<News> newsList = new ArrayList<News>();
		newsList = newsService.readHeadlineFromDB();
		for (News news : newsList) {
			System.out.println(news.getNewsid());
		}
		return new ModelAndView("deleteNewsDisplay", "newsList", newsList);

	}

	// ****************************************************************************************************//*
	@RequestMapping(value = "/deleteNews")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView deleteNews(@RequestParam(value = "newsids", required = false) String newsids ,HttpServletRequest request) {
		if (newsids != null) {
			ArrayList<News> newsList = new ArrayList<News>();

			for (String newsid : newsids.split(",")) {
				News news = new News();
				news.setNewsid(Integer.parseInt(newsid));
				newsList.add(news);
			}
			newsService.archiveFromDB(newsList);
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Success");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/viewAllNewsHeadlines',true;");
			return model;
		} else {

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "please select a news");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/viewAllNewsHeadlines',true;");
			return model;
		}

	}

	// ****************************************************************************************************//*
	@RequestMapping(value = "/updateNewsPage")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateNewsPage() {

		ArrayList<News> newsList = new ArrayList<News>();
		newsList = newsService.readHeadlineFromDB();
		return new ModelAndView("updateNewsDisplay", "newsList", newsList);

	}

	@RequestMapping(value = "/updateNewsMenu/{name}")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateNewsMenu(@PathVariable("name") int newsid) {
		System.out.println(newsid);
		News news = new News();
		news = newsService.fetchFromDBUsingId(newsid);
		return new ModelAndView("updateNewsForm", "news", news);
	}

	@RequestMapping(value = "/updateNewsFinal", method = RequestMethod.POST)
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView updateNewsFinal(
			@RequestParam("image") MultipartFile filePart,
			@RequestParam("newsid") int newsid,
			@RequestParam("headline") String headline,
			@RequestParam("content") String content,
			@RequestParam(value = "fileUpload", required = false) CommonsMultipartFile pdfFileUpload, 
			HttpServletRequest request)
			throws IOException {

		System.out.println("===============================");
		News news = new News();

		/* source code of tika for image */
		
		InputStream is1 = filePart.getInputStream();
		FileValidator filevalidator=new FileValidator();
		String mediaType11=filevalidator.fileValidator(is1, filePart); 
		String filetype = mediaType11.substring(0, 5);
		System.out.println("type of the image is "+filetype);
		
		/* source code of tika for PDF FILE */
		InputStream is = pdfFileUpload.getInputStream(); 
		String mediatype1=filevalidator.fileValidator(is, pdfFileUpload); 
		System.out.println("type of the pdf is "+mediatype1);
		 
	
		if (filetype.equalsIgnoreCase("image")
				|| mediaType11.equalsIgnoreCase("application/octet-stream")) {
			news.setNewsid(newsid);
			news.setHeadline(headline);
			news.setContent(content);
			news.setDateadded(new Date(System.currentTimeMillis()));
			if (mediatype1.equalsIgnoreCase("application/octet-stream")
					|| mediatype1.equalsIgnoreCase("application/pdf")) {
				news.setPdffile(pdfFileUpload.getBytes());

			}

			else {
				ModelAndView model = new ModelAndView("alert");
				model.addObject("alertMessage",
						"please select a valid pdf file");
				model.addObject("location",
						"document.location.href = '"+request.getContextPath()+"/updateNewsPage',true;");
				return model;
			}

			System.out.println("before write to database  ");

			newsService.writeUpdateToDB(news, filePart);
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Success");
			model.addObject("location",
					"document.location.href = '"+request.getContextPath()+"/updateNewsPage',true;");
			return model;
		} else {
			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "please select a valid image file");
			model.addObject("location",
					"document.location.href = '"+request.getContextPath()+"/updateNewsPage',true;");
			return model;
		}

	}

	/*
	 * @RequestMapping(value = "/news/{name}") public ModelAndView
	 * newsNeeded(@PathVariable("name") int a) { News news = new News(); news =
	 * newsService.fetchFromDBUsingId(a); System.out.println(news.getHeadline()
	 * + news.getNewsid()); return new ModelAndView("newsExpand", "newsList",
	 * news); }
	 */

	@RequestMapping(value = "/unarchive")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView unarchive() {
		ArrayList<News> newsList = new ArrayList<News>();
		newsList = newsService.readHeadlineFromDB1();
		return new ModelAndView("UnarchiveSelect", "newsList", newsList);

	}

	@RequestMapping(value = "/deleteNews1")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ModelAndView deleteNews1(@RequestParam(value = "newsids", required = false) String newsids ,HttpServletRequest request) {
		if (newsids != null) {
			ArrayList<News> newsList = new ArrayList<News>();

			for (String newsid : newsids.split(",")) {
				News news = new News();
				news.setNewsid(Integer.parseInt(newsid));
				newsList.add(news);
			}
			newsService.unarchiveFromDB1(newsList);

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "Success");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/unarchive',true;");
			return model;
		} else {

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "please select a news");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/unarchive',true;");
			return model;
		}
	}

	@RequestMapping(value = "/downloadPdf/{idOfPdfToBeDownloaded}")
	public ModelAndView downloadPdf(@PathVariable("idOfPdfToBeDownloaded" ) int idOfPdfToBeDownloaded,
			HttpServletResponse response ,HttpServletRequest request) {
		News blobPdf = newsService.getPdf(idOfPdfToBeDownloaded);
		if (blobPdf.getPdffile() != null) {
			/*OutputStream out = null;
			try {

				out = new FileOutputStream(idOfPdfToBeDownloaded + ".pdf");
				out.write(blobPdf.getPdffile());
				out.flush();
				out.close();
				File file = new File("D:\\FinalProject\\project\\" + idOfPdfToBeDownloaded + ".pdf");
				InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
				String mimeType = URLConnection.guessContentTypeFromStream(inputStream);

				if (mimeType == null) {
					mimeType = "application/octet-stream";
				}
				response.setContentType(mimeType);
				response.setContentLength((int) file.length());
				response.setHeader("content-Disposition", String.format("attatchment;filename=\"%s\"", file.getName()));
				FileCopyUtils.copy(inputStream, response.getOutputStream());
				return null;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				ModelAndView model = new ModelAndView("alert");
				model.addObject("alertMessage", "failed");
				model.addObject("location", "document.location.href = '/project/viewAllNews',true;");
				return model;
			} catch (IOException e) {
				e.printStackTrace();
				ModelAndView model = new ModelAndView("alert");
				model.addObject("alertMessage", "failed");
				model.addObject("location", "document.location.href = '/project/viewAllNews',true;");
				return model;
			}*/
			
			try
			{
				streamReport(response, blobPdf.getPdffile(), idOfPdfToBeDownloaded+".pdf");
				return null;
			}
			catch (Exception e) 
			{
				ModelAndView model = new ModelAndView("alert");
				model.addObject("alertMessage", "No Pdf Available For this news");
				model.addObject("location", "document.location.href = '"+request.getContextPath()+"/viewAllNews',true;");
				return model;
			}
		} else {

			ModelAndView model = new ModelAndView("alert");
			model.addObject("alertMessage", "No Pdf Available For this news");
			model.addObject("location", "document.location.href = '"+request.getContextPath()+"/viewAllNews',true;");
			return model;
		}

	}
	
	
	/**
	 * @author Mukesh Dewangan
	 * @since 14 November 2018
	 * This function will return response as pdf
	 */
	protected void streamReport(HttpServletResponse response, byte[] data, String name)
            throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-disposition", "attachment; filename=" + name);
        response.setContentLength(data.length);
        response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
        response.getOutputStream().write(data);
        response.getOutputStream().flush();
    }
}
