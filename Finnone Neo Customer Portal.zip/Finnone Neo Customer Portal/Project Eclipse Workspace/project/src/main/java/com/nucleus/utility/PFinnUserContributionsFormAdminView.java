package com.nucleus.utility;

import java.util.List;

import com.nucleus.pojo.PFinnUserContribution;

/**
 * @author Mukesh Dewangan
 * @since 20 September 2018
 * 
 */
public class PFinnUserContributionsFormAdminView {
	List<PFinnUserContribution> pFinnUserContributionsList;

	public PFinnUserContributionsFormAdminView() {
		super();
	}

	public PFinnUserContributionsFormAdminView(List<PFinnUserContribution> pFinnUserContributionsList) {
		super();
		this.pFinnUserContributionsList = pFinnUserContributionsList;
	}

	public List<PFinnUserContribution> getpFinnUserContributionsList() {
		return pFinnUserContributionsList;
	}

	public void setpFinnUserContributionsList(List<PFinnUserContribution> pFinnUserContributionsList) {
		this.pFinnUserContributionsList = pFinnUserContributionsList;
	}
}
