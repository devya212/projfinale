package com.nucleus.service;

import java.util.List;
import java.util.Map;

import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnUserContribution;

public interface UserService {
	public void newMember(PFinnNewUser up);

	public int checkUnique(PFinnNewUser up);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public List<PFinnUserContribution> serviceViewAll();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public List<String> getCategoryRatings();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public void updateUserContributionsList(List<PFinnUserContribution> pFinnUserContributionsList);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public Map<String, String> category();

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public void save(PFinnUserContribution pFinnUserContribution);

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	public PFinnNewUser getUserByUserName(String userName);

	public List<PFinnNewUser> readNotApprovedUsersFromDB();

	public void approveNewUser(String userIdToBeApproved);

	public int checkApprovalStatus(String userNameToBeChecked);

	public void deniedApproval(int userId);
}
