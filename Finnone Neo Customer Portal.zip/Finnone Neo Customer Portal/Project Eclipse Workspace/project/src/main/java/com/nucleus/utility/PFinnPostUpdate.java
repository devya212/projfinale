package com.nucleus.utility;

import java.util.List;

import com.nucleus.pojo.DiscussionPost;

/**
 * @author Ajita Mittal
 * @since 25 September 2018 Pojo for the admin Post view of discussion thread
 *        for the status updation
 */
public class PFinnPostUpdate {
	List<DiscussionPost> pFinnUserPostList;

	public PFinnPostUpdate() {
		super();
	}

	public PFinnPostUpdate(List<DiscussionPost> pFinnUserPostList) {
		super();
		this.pFinnUserPostList = pFinnUserPostList;
	}

	public List<DiscussionPost> getpFinnUserPostList() {
		return pFinnUserPostList;
	}

	public void setpFinnUserPostList(List<DiscussionPost> pFinnUserPostList) {
		this.pFinnUserPostList = pFinnUserPostList;
	}
}
