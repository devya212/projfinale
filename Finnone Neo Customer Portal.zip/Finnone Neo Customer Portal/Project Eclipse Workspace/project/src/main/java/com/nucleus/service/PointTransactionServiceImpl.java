package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.PointTransactionDao;
import com.nucleus.pojo.Badge;
import com.nucleus.pojo.Gifts;
import com.nucleus.pojo.PFinnUserContribution;
import com.nucleus.pojo.UserReward;
import com.nucleus.pojo.UserTransaction;

@Service
@Transactional
public class PointTransactionServiceImpl implements PointTransactionService {
	@Autowired
	PointTransactionDao pdao;

	@Override
	public List<UserTransaction> getWithdrawalPoints(long userId) {
		return pdao.getWithdrawalPoints(userId);
	}

	@Override
	public List<PFinnUserContribution> fetch() {
		return pdao.fetch();
	}

	@Override
	public int fetchRewardPointsFromEventMaster(PFinnUserContribution contribution) {
		return pdao.fetchRewardPointsFromEventMaster(contribution);
	}

	@Override
	public void saveToTransactionTable(UserTransaction transaction) {
		pdao.saveToTransactionTable(transaction);

	}

	@Override
	public List<UserTransaction> getDepositPoints(long userId) {
		return pdao.getDepositPoints(userId);
	}

	@Override
	public int totalContribution(long userId) {
		return pdao.totalContribution(userId);
	}

	@Override
	public long fetchUserId(String username) {
		return pdao.fetchUserId(username);
	}

	@Override
	public void pushToRewardTable(UserReward userReward) {
		pdao.pushToRewardTable(userReward);

	}

	@Override
	public UserReward fetchRewardTable(long userId) {
		return pdao.fetchRewardTable(userId);
	}

	@Override
	public List<UserTransaction> fetchTransactionTable(long userId) {
		return pdao.fetchTransactionTable(userId);
	}

	@Override
	public List<PFinnUserContribution> fetchNewTransaction() {
		return pdao.fetchNewTransaction();
	}

	@Override
	public int totalFeedback(long userId) {
		return pdao.totalFeedback(userId);
	}

	@Override
	public int totalSuggestions(long userId) {
		return pdao.totalSuggestions(userId);
	}

	@Override
	public int totalNewIdeas(long userId) {
		return pdao.totalNewIdeas(userId);
	}

	@Override
	public Gifts getGiftPoints(String giftName) {

		return pdao.getGiftPoints(giftName);
	}

	@Override
	public Badge getBadge(int rewardPoints) {

		return pdao.getBadge(rewardPoints);
	}
}
