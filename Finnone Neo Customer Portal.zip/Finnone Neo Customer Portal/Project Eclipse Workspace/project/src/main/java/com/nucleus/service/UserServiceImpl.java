package com.nucleus.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.dao.UserDao;
import com.nucleus.functions.PasswordEncoder;
import com.nucleus.pojo.PFinnNewUser;
import com.nucleus.pojo.PFinnRole;
import com.nucleus.pojo.PFinnUserContribution;

@Transactional
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;

	@Override
	public void newMember(PFinnNewUser userPojo) {
		PFinnRole userRolePojo = new PFinnRole();

		String password = userPojo.getPass();
		PasswordEncoder passwordEncoder = new PasswordEncoder();
		String pass = passwordEncoder.encode(password);

		userRolePojo.setRoleId(2);
		userRolePojo.setRoleName("ROLE_USER");
		userPojo.setEnabled(1);
		userPojo.setPass(pass);
		userPojo.setApprovalStatus("not approved");
		userPojo.setUserRolePojo(userRolePojo);
		dao.newMember(userPojo);

	}

	@Override
	public int checkUnique(PFinnNewUser userPojo) {
		int exist = dao.existance(userPojo);
		return exist;
	}

	/*
	 * @Override public void newMember(PFinnNewUser up) { PFinnRole urp = new
	 * PFinnRole();
	 * 
	 * String password = up.getPass(); PasswordEncoder p = new
	 * PasswordEncoder(); String pass = p.encode(password);
	 * 
	 * urp.setRoleId(2); urp.setRoleName("ROLE_USER"); up.setEnabled(1);
	 * up.setPass(pass); up.setUrp(urp); dao.newMember(up);
	 * 
	 * }
	 */

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public Map<String, String> category() {
		return dao.category();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public List<PFinnUserContribution> serviceViewAll() {
		return dao.viewAll();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public List<String> getCategoryRatings() {
		return dao.getCategoryRatings();
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public void updateUserContributionsList(List<PFinnUserContribution> pFinnUserContributionsList) {
		for (PFinnUserContribution pFinnUserContribution : pFinnUserContributionsList) {
			if (pFinnUserContribution.getStatus() != null && !pFinnUserContribution.getStatus().equalsIgnoreCase(""))
				pFinnUserContribution.setStatusDate(new Date(System.currentTimeMillis()));
		}
		System.out.println(pFinnUserContributionsList);
		dao.updateUserContributionsList(pFinnUserContributionsList);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public void save(PFinnUserContribution pFinnUserContribution) {
		dao.save(pFinnUserContribution);
	}

	/**
	 * @author Mukesh Dewangan
	 * @since 20 September 2018
	 */
	@Override
	public PFinnNewUser getUserByUserName(String userName) {
		return dao.getUserByUserName(userName);
	}

	@Override
	public List<PFinnNewUser> readNotApprovedUsersFromDB() {
		List<PFinnNewUser> notApprovedUsers = dao.readNotApprovedUsersFromDB();
		return notApprovedUsers;
	}

	@Override
	public void approveNewUser(String userIdToBeApproved) {
		dao.approveNewUser(userIdToBeApproved);

	}

	@Override
	public int checkApprovalStatus(String userNameToBeChecked) {

		PFinnNewUser user = dao.checkApprovalStatus(userNameToBeChecked);
		if (user.getApprovalStatus().equalsIgnoreCase("approved")) {
			return 1;
		} else {
			return 0;
		}
	}

	@Override
	public void deniedApproval(int userId) {

		dao.deniedApproval(userId);
	}

}
